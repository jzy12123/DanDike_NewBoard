/*
 * File: FFT2C_initialize.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 31-May-2024 16:43:36
 */

#ifndef FFT2C_INITIALIZE_H
#define FFT2C_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void FFT2C_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for FFT2C_initialize.h
 *
 * [EOF]
 */
