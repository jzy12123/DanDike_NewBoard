/*
 * File: FFT2C_initialize.c
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 31-May-2024 16:43:36
 */

/* Include Files */
#include "FFT2C_initialize.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void FFT2C_initialize(void)
{
}

/*
 * File trailer for FFT2C_initialize.c
 *
 * [EOF]
 */
