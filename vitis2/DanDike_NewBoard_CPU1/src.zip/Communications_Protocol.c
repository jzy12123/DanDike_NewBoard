/*
 * ���ļ���ĺ�����������linux������JSONָ��
 * ͬʱ���岢�ϱ�UDP�ṹ��
 * ���ṹ�����ɡ�
	(
		֡ͷ������16�ֽڣ�
			ͬ��ͷ��			4�ֽ�		�̶�Ϊ��D1D2D3D4
			�������ܳ���1��		4�ֽڣ�ֵΪn��
			�������ܳ���2��		4�ֽڣ�ֵΪn���ظ���
			�汾��Ϣ�� 			   1�ֽ�
			������				       3�ֽ�

		����������n�ֽڣ�	����ṹ�ɶ���ṹ����ʽ��ɡ�
			�ṹ�����ͱ�ʶ��	4�ֽ�
			�ṹ�����ݳ��ȣ�	4�ֽ�
			�ṹ�����ݣ�		n1�ֽ�

			�ṹ�����ͱ�ʶ��	4�ֽ�
			�ṹ�����ݳ��ȣ�	4�ֽ�
			�ṹ�����ݣ�		n2�ֽ�
			...

		֡β������4�ֽڣ�
			��������			4�ֽ�		�̶�Ϊ��E1E2E3E4
	)
 *
 */
#include "Communications_Protocol.h"
/*
 * ����JSONָ��㺯��
 */
int Parse_JsonCommand(char *buffer){
	FunCodeMap funCodeMap[] = {
			{"GetFunCodeList", handle_GetFunCodeList},
			{"GetDevBaseInfo", handle_GetDevBaseInfo},
			{"GetDevState", handle_GetDevState},
			{"SetReportEnable", handle_SetReportEnable},
			{"SetDCS", handle_SetDCS},
			{"SetDCM", handle_SetDCM},
			{"SetACS", handle_SetACS},
			{"SetACM", handle_SetACM},
			{"SetHarm", handle_SetHarm},
			{"SetInterHarm", handle_SetInterHarm},
			{"SetDO", handle_SetDO},
			{"StopDCS", handle_StopDCS},
			{"StopAC", handle_StopAC},
			{"ClearHarm", handle_ClearHarm},
			{"ClearInterHarm", handle_ClearInterHarm}
	};
	const int funCodeMapSize = sizeof(funCodeMap) / sizeof(funCodeMap[0]);

	//��������ַ�����β�� '|'
    int len = strlen(buffer);
    // ��鲢ȥ����β�� '|'
    if (buffer[0] == '|' && buffer[len - 1] == '|') {
        memmove(buffer, buffer + 1, len - 2); // ������ǰ�ƣ����ǵ�һ�� '|'
        buffer[len - 2] = '\0'; // �����ַ���������
        printf("CPU1: Remove | \n");
    }

	//��ӡbuffer�������
    printf("CPU1: Recived_JSON: %s\n", buffer);

	// ʹ��cJSON����JSON�ַ���
	cJSON *json = cJSON_Parse(buffer);
	if (json == NULL) {
		xil_printf("Failed to parse JSON.\n");
		return 1;
	}

	cJSON *funCodeItem = cJSON_GetObjectItem(json, "FunCode");
	if (funCodeItem == NULL) {
		xil_printf("No FunCode found in JSON.\n");
		cJSON_Delete(json);
		return 1;
	}

	const char *funCode = cJSON_GetStringValue(funCodeItem);
	xil_printf("CPU1: FunCode: %s\r\n", funCode);
	xil_printf("\r\n");

	// ����Data
	cJSON *data = cJSON_GetObjectItem(json, "Data");

	// ���� FunCode ��ת����Ӧ�Ĵ�������
	for (int i = 0; i < funCodeMapSize; i++) {
		if (strcmp(funCode, funCodeMap[i].funCode) == 0) {
			funCodeMap[i].handler(data);
			break;
		}
	}

	cJSON_Delete(json);

    return 0;
}



void handle_GetFunCodeList(cJSON *data) {
    // ���� GetFunCodeList ���߼�
//    xil_printf("Handling handle_GetFunCodeList...\n");

    // ���� FunCode �б�
    const char *CmdList[] = {
    		"GetFunCodeList", "GetDevBaseInfo", "GetDevState", "SetReportEnable",
			"SetDCS", "SetDCM", "SetACS", "SetACM", "SetHarm", "SetInterHarm", "SetDO",
			"StopDCS", "StopACS", "ClearHarm", "ClearInterHarm"
    };

    const char *ReportList[] = {
    		"ProtectEvent", "DISOE", "BaseDataAC", "BaseDataDC", "BaseDataIO", "HarmData", "InterHarmData"
    };

    const char *TaskEventList[] = {
    		"SetSyncMode", "SetProgress"
    };

    // ��������ָ��� JSON ����
    cJSON *reply = cJSON_CreateObject();
    cJSON_AddStringToObject(reply, "FunType", "Reply");
    cJSON_AddStringToObject(reply, "FunCode", "GetFunCodeList");
    cJSON_AddStringToObject(reply, "Result", "Success");

    cJSON *dataObj = cJSON_CreateObject();

    cJSON *cmdList = cJSON_CreateStringArray(CmdList, sizeof(CmdList) / sizeof(CmdList[0]));
    cJSON_AddItemToObject(dataObj, "CmdList", cmdList);

    cJSON *reportList = cJSON_CreateStringArray(ReportList, sizeof(ReportList) / sizeof(ReportList[0]));
    cJSON_AddItemToObject(dataObj, "ReportList", reportList);

    cJSON *taskEventList = cJSON_CreateStringArray(TaskEventList, sizeof(TaskEventList) / sizeof(TaskEventList[0]));
    cJSON_AddItemToObject(dataObj, "TaskEventList", taskEventList);

    cJSON_AddItemToObject(reply, "Data", dataObj);

    // �����ɵ� JSON ת��Ϊ�ַ���
    char *string = cJSON_Print(reply);
    if (string == NULL) {
        xil_printf("Failed to print JSON.\n");
        cJSON_Delete(reply);
        return;
    }

    // ���ַ�����β���� '|' �ַ�
    size_t stringLength = strlen(string);
    char *finalString = (char *)malloc(stringLength + 3); // +3 Ϊ����β '|' �ͽ�����
    if (finalString == NULL) {
        xil_printf("Failed to allocate memory for final JSON string.\n");
        cJSON_Delete(reply);
        free(string);
        return;
    }
    snprintf(finalString, stringLength + 3, "|%s|", string);

    // �����ɵ� JSON д�빲���ڴ�
    ssize_t bytesWritten = MsgQue_write(finalString,strlen(finalString));
	if (bytesWritten < 0) {
		xil_printf("CPU1:Failed to write to message queue: %ld\n", bytesWritten);
	} else {
//		xil_printf("CPU1:Successfully wrote %ld bytes to message queue: %s\n", bytesWritten, string);
	}



    // ����
	free(finalString);
    cJSON_Delete(reply);
    free(string);
}

void handle_GetDevBaseInfo(cJSON *data) {
    // ���� GetDevBaseInfo ���߼�
//    xil_printf("Handling handle_GetDevBaseInfo...\n");

    // ��������ָ��� JSON ����
    cJSON *reply = cJSON_CreateObject();
    cJSON_AddStringToObject(reply, "FunType", "Reply");
    cJSON_AddStringToObject(reply, "FunCode", "GetDevBaseInfo");
    cJSON_AddStringToObject(reply, "Result", "Success");

    cJSON *dataObj = cJSON_CreateObject();
    cJSON_AddStringToObject(dataObj, "Model", "xxx");
    cJSON_AddStringToObject(dataObj, "InnerModel", "DK-34B1");
    cJSON_AddStringToObject(dataObj, "FPGA_Ver", "1.0.1");
    cJSON_AddStringToObject(dataObj, "ARM_Ver", "1.0.1");

    const char *syncModes[] = {"GPS", "BD", "IRIG-B", "SNTP", "Manual"};
    cJSON *syncMode = cJSON_CreateStringArray(syncModes, 5);
    cJSON_AddItemToObject(dataObj, "SyncMode", syncMode);

    // DI ��Ϣ
    cJSON *di = cJSON_CreateObject();
    cJSON_AddNumberToObject(di, "ChnCount", ChnsBI);
    double diResolution[] = {0.1, 1, 10};//����ֱ���
    cJSON *diResolutions = cJSON_CreateDoubleArray(diResolution, 3);
    cJSON_AddItemToObject(di, "DI_Resolution", diResolutions);
    cJSON_AddItemToObject(dataObj, "DI", di);

    // DO ��Ϣ
    cJSON *doInfo = cJSON_CreateObject();
    cJSON_AddNumberToObject(doInfo, "ChnCount", ChnsBO);
    cJSON_AddItemToObject(dataObj, "DO", doInfo);

    // AC ��Ϣ
    cJSON *ac = cJSON_CreateObject();
    const char *acModes[] = {"S", "M"};
    cJSON *acMode = cJSON_CreateStringArray(acModes, 2);
    cJSON_AddItemToObject(ac, "Mode", acMode);
    cJSON_AddNumberToObject(ac, "MaxHarmNumber", HarmNumberMax);
    cJSON_AddNumberToObject(ac, "LineCount", LinesAC);
    cJSON_AddNumberToObject(ac, "ChnCount", ChnsAC);

    cJSON *acChns = cJSON_CreateArray();
    for (int line = 1; line <= LinesAC; line++) {
        for (int chn = 1; chn <= ChnsAC; chn++) {
            cJSON *chnObj = cJSON_CreateObject();
            cJSON_AddNumberToObject(chnObj, "Line", line);
            cJSON_AddNumberToObject(chnObj, "Chn", chn);

            double urValues[] = {57.7, 100, 220, 380};
            cJSON *urArray = cJSON_CreateDoubleArray(urValues, 4);
            cJSON_AddItemToObject(chnObj, "URs", urArray);

            double irValues[] = {1, 5, 10, 100};
            cJSON *irArray = cJSON_CreateDoubleArray(irValues, 4);
            cJSON_AddItemToObject(chnObj, "IRs", irArray);

            cJSON_AddItemToArray(acChns, chnObj);
        }
    }
    cJSON_AddItemToObject(ac, "Chns", acChns);
    cJSON_AddItemToObject(dataObj, "AC", ac);

    // DCS ��Ϣ
    cJSON *dcs = cJSON_CreateObject();
    cJSON_AddNumberToObject(dcs, "ChnCount", ChnsDCS);

    cJSON *dcsChns = cJSON_CreateArray();
    for (int chn = 1; chn <= ChnsDCS; chn++) {
        cJSON *chnObj = cJSON_CreateObject();
        cJSON_AddNumberToObject(chnObj, "Chn", chn);

        double urValues[] = {57.7, 100, 220, 380};
        cJSON *urArray = cJSON_CreateDoubleArray(urValues, 4);
        cJSON_AddItemToObject(chnObj, "URs", urArray);

        double irValues[] = {1, 5, 10, 100};
        cJSON *irArray = cJSON_CreateDoubleArray(irValues, 4);
        cJSON_AddItemToObject(chnObj, "IRs", irArray);

        cJSON_AddItemToArray(dcsChns, chnObj);
    }
    cJSON_AddItemToObject(dcs, "Chns", dcsChns);
    cJSON_AddItemToObject(dataObj, "DCS", dcs);

    // DCM ��Ϣ
    cJSON *dcm = cJSON_CreateObject();
    cJSON_AddNumberToObject(dcm, "ChnCount", ChnsDCM);

    cJSON *dcmChns = cJSON_CreateArray();
    for (int chn = 1; chn <= ChnsDCM; chn++) {
        cJSON *chnObj = cJSON_CreateObject();
        cJSON_AddNumberToObject(chnObj, "Chn", chn);

        double urValues[] = {57.7, 100, 220, 380};
        cJSON *urArray = cJSON_CreateDoubleArray(urValues, 4);
        cJSON_AddItemToObject(chnObj, "URs", urArray);

        double irValues[] = {1, 5, 10, 100};
        cJSON *irArray = cJSON_CreateDoubleArray(irValues, 4);
        cJSON_AddItemToObject(chnObj, "IRs", irArray);

        cJSON_AddItemToArray(dcmChns, chnObj);
    }
    cJSON_AddItemToObject(dcm, "Chns", dcmChns);
    cJSON_AddItemToObject(dataObj, "DCM", dcm);

    cJSON_AddItemToObject(reply, "Data", dataObj);

    // �����ɵ� JSON ת��Ϊ�ַ���
    char *string = cJSON_Print(reply);
    if (string == NULL) {
        xil_printf("Failed to print JSON.\n");
        cJSON_Delete(reply);
        return;
    }

    // ���ַ�����β���� '|' �ַ�
    size_t stringLength = strlen(string);
    char *finalString = (char *)malloc(stringLength + 3); // +3 Ϊ����β '|' �ͽ�����
    if (finalString == NULL) {
        xil_printf("Failed to allocate memory for final JSON string.\n");
        cJSON_Delete(reply);
        free(string);
        return;
    }
    snprintf(finalString, stringLength + 3, "|%s|", string);

    // �����ɵ� JSON д�빲���ڴ�
    ssize_t bytesWritten = MsgQue_write(finalString,strlen(finalString));
	if (bytesWritten < 0) {
		xil_printf("CPU1:Failed to write to message queue: %ld\n", bytesWritten);
	} else {
//		xil_printf("CPU1:Successfully wrote %ld bytes to message queue: %s\n", bytesWritten, string);
	}



    // ����
	free(finalString);
    cJSON_Delete(reply);
    free(string);
}

void handle_GetDevState(cJSON *data) {
	// ���� handle_GetDevState ���߼�
//	xil_printf("Handling handle_GetDevState...\n");

	// ��������ָ��� JSON ����
	cJSON *reply = cJSON_CreateObject();
	cJSON_AddStringToObject(reply, "FunType", "Reply");
	cJSON_AddStringToObject(reply, "FunCode", "GetDevState");
	cJSON_AddStringToObject(reply, "Result", "Success");

	cJSON *dataObj = cJSON_CreateObject();
	cJSON_AddStringToObject(dataObj, "DevTime", "2024-01-31 00:00:00.123");
	cJSON_AddNumberToObject(dataObj, "Temperature", 24);
	cJSON_AddStringToObject(dataObj, "SyncMode", "GPS");
	cJSON_AddNumberToObject(dataObj, "Longitude", 12.2);
	cJSON_AddNumberToObject(dataObj, "Latitude", 12.2);
	cJSON_AddNumberToObject(dataObj, "DI_Resolution", 0.1);

	cJSON *task = cJSON_CreateObject();
	cJSON_AddStringToObject(task, "FunCode", "");
	cJSON_AddStringToObject(task, "StartTime", "2024-01-31 00:00:00.123");
	cJSON_AddItemToObject(dataObj, "Task", task);

	// AC ��Ϣ
	cJSON *ac = cJSON_CreateObject();
	cJSON_AddStringToObject(ac, "Mode", "S");
	cJSON_AddBoolToObject(ac, "ClosedLoop", true);

	cJSON *acChns = cJSON_CreateArray();
	for (int line = 1; line <= LinesAC; line++) {
		for (int chn = 1; chn <= ChnsAC; chn++) {
			cJSON *chnObj = cJSON_CreateObject();
			cJSON_AddNumberToObject(chnObj, "Line", line);
			cJSON_AddNumberToObject(chnObj, "Chn", chn);
			cJSON_AddNumberToObject(chnObj, "UR", 57.7);
			cJSON_AddNumberToObject(chnObj, "IR", 5);
			cJSON_AddItemToArray(acChns, chnObj);
		}
	}
	cJSON_AddItemToObject(ac, "Chns", acChns);
	cJSON_AddItemToObject(dataObj, "AC", ac);

	// DCS ��Ϣ
	cJSON *dcs = cJSON_CreateArray();
	for (int chn = 1; chn <= ChnsDCS; chn++) {
		cJSON *chnObj = cJSON_CreateObject();
		cJSON_AddNumberToObject(chnObj, "Chn", chn);
		cJSON_AddNumberToObject(chnObj, "UR", 57.7);
		cJSON_AddNumberToObject(chnObj, "IR", 1);
		cJSON_AddItemToArray(dcs, chnObj);
	}
	cJSON_AddItemToObject(dataObj, "DCS", dcs);

	// DCM ��Ϣ
	cJSON *dcm = cJSON_CreateArray();
	for (int chn = 1; chn <= ChnsDCM; chn++) {
		cJSON *chnObj = cJSON_CreateObject();
		cJSON_AddNumberToObject(chnObj, "Chn", chn);
		cJSON_AddNumberToObject(chnObj, "UR", 57.7);
		cJSON_AddNumberToObject(chnObj, "IR", 1);
		cJSON_AddItemToArray(dcm, chnObj);
	}
	cJSON_AddItemToObject(dataObj, "DCM", dcm);

	// DO ��Ϣ
	cJSON *doInfo = cJSON_CreateArray();
	for (int i = 0; i < ChnsBO; i++) {
		cJSON_AddItemToArray(doInfo, cJSON_CreateNumber(i % 2));  // ����DO״̬��0��1����
	}
	cJSON_AddItemToObject(dataObj, "DO", doInfo);

	// DI ��Ϣ
	cJSON *diInfo = cJSON_CreateArray();
	for (int i = 0; i < ChnsBI; i++) {
		cJSON_AddItemToArray(diInfo, cJSON_CreateNumber(i % 2));  // ����DI״̬��0��1����
	}
	cJSON_AddItemToObject(dataObj, "DI", diInfo);

	cJSON_AddItemToObject(reply, "Data", dataObj);

	//ӳ�䵽Ӳ��
	//�������ź�
//	RdSerial();

    // �����ɵ� JSON ת��Ϊ�ַ���
    char *string = cJSON_Print(reply);
    if (string == NULL) {
        xil_printf("Failed to print JSON.\n");
        cJSON_Delete(reply);
        return;
    }

    // ���ַ�����β���� '|' �ַ�
    size_t stringLength = strlen(string);
    char *finalString = (char *)malloc(stringLength + 3); // +3 Ϊ����β '|' �ͽ�����
    if (finalString == NULL) {
        xil_printf("Failed to allocate memory for final JSON string.\n");
        cJSON_Delete(reply);
        free(string);
        return;
    }
    snprintf(finalString, stringLength + 3, "|%s|", string);

    // �����ɵ� JSON д�빲���ڴ�
    ssize_t bytesWritten = MsgQue_write(finalString,strlen(finalString));
	if (bytesWritten < 0) {
		xil_printf("CPU1:Failed to write to message queue: %ld\n", bytesWritten);
	} else {
//		xil_printf("CPU1:Successfully wrote %ld bytes to message queue: %s\n", bytesWritten, string);
	}



    // ����
	free(finalString);
    cJSON_Delete(reply);
    free(string);
}

ReportEnableStatus reportStatus = {true, true, true, true, true, true, true, true, true, true};
void handle_SetReportEnable(cJSON *data) {
    // ���� handle_SetReportEnable ���߼�
//    xil_printf("Handling handle_SetReportEnable...\n");

    // ����ʹ��״̬
    cJSON *BaseDataAC = cJSON_GetObjectItem(data, "BaseDataAC");
    if (BaseDataAC != NULL) {
    	reportStatus.BaseDataAC = cJSON_IsTrue(BaseDataAC);
    }

    cJSON *HarmData = cJSON_GetObjectItem(data, "HarmData");
    if (HarmData != NULL) {
    	reportStatus.HarmData = cJSON_IsTrue(HarmData);
    }

    cJSON *InterHarmData = cJSON_GetObjectItem(data, "InterHarmData");
    if (InterHarmData != NULL) {
    	reportStatus.InterHarmData = cJSON_IsTrue(InterHarmData);
    }

    cJSON *BaseDataDCS = cJSON_GetObjectItem(data, "BaseDataDCS");
    if (BaseDataDCS != NULL) {
    	reportStatus.BaseDataDCS = cJSON_IsTrue(BaseDataDCS);
    }

    cJSON *BaseDataDCM = cJSON_GetObjectItem(data, "BaseDataDCM");
    if (BaseDataDCM != NULL) {
    	reportStatus.BaseDataDCM = cJSON_IsTrue(BaseDataDCM);
    }

    cJSON *DI = cJSON_GetObjectItem(data, "DI");
    if (DI != NULL) {
    	reportStatus.DI = cJSON_IsTrue(DI);
    }

    cJSON *DISOE = cJSON_GetObjectItem(data, "DISOE");
    if (DISOE != NULL) {
    	reportStatus.DISOE = cJSON_IsTrue(DISOE);
    }

    cJSON *DO = cJSON_GetObjectItem(data, "DO");
    if (DO != NULL) {
    	reportStatus.DO = cJSON_IsTrue(DO);
    }

    cJSON *InnerBattery = cJSON_GetObjectItem(data, "InnerBattery");
    if (InnerBattery != NULL) {
    	reportStatus.InnerBattery = cJSON_IsTrue(InnerBattery);
    }

    cJSON *VMData = cJSON_GetObjectItem(data, "VMData");
    if (VMData != NULL) {
    	reportStatus.VMData = cJSON_IsTrue(VMData);
    }




    /*��������ָ��� JSON ����*/
    cJSON *reply = cJSON_CreateObject();
    cJSON_AddStringToObject(reply, "FunType", "Reply");
    cJSON_AddStringToObject(reply, "FunCode", "SetReportEnable");
    cJSON_AddStringToObject(reply, "Result", "Success");

    cJSON *dataObj = cJSON_CreateObject();
    cJSON_AddBoolToObject(dataObj, "BaseDataAC", reportStatus.BaseDataAC);
    cJSON_AddBoolToObject(dataObj, "HarmData", reportStatus.HarmData);
    cJSON_AddBoolToObject(dataObj, "InterHarmData", reportStatus.InterHarmData);
    cJSON_AddBoolToObject(dataObj, "BaseDataDCS", reportStatus.BaseDataDCS);
    cJSON_AddBoolToObject(dataObj, "BaseDataDCM", reportStatus.BaseDataDCM);
    cJSON_AddBoolToObject(dataObj, "DI", reportStatus.DI);
    cJSON_AddBoolToObject(dataObj, "DISOE", reportStatus.DISOE);
    cJSON_AddBoolToObject(dataObj, "DO", reportStatus.DO);
    cJSON_AddBoolToObject(dataObj, "InnerBattery", reportStatus.InnerBattery);
    cJSON_AddBoolToObject(dataObj, "VMData", reportStatus.VMData);

    cJSON_AddItemToObject(reply, "Data", dataObj);

    // �����ɵ� JSON ת��Ϊ�ַ���
    char *string = cJSON_Print(reply);
    if (string == NULL) {
        xil_printf("Failed to print JSON.\n");
        cJSON_Delete(reply);
        return;
    }

    // ���ַ�����β���� '|' �ַ�
    size_t stringLength = strlen(string);
    char *finalString = (char *)malloc(stringLength + 3); // +3 Ϊ����β '|' �ͽ�����
    if (finalString == NULL) {
        xil_printf("Failed to allocate memory for final JSON string.\n");
        cJSON_Delete(reply);
        free(string);
        return;
    }
    snprintf(finalString, stringLength + 3, "|%s|", string);

    // �����ɵ� JSON д�빲���ڴ�
    ssize_t bytesWritten = MsgQue_write(finalString,strlen(finalString));
	if (bytesWritten < 0) {
		xil_printf("CPU1:Failed to write to message queue: %ld\n", bytesWritten);
	} else {
//		xil_printf("CPU1:Successfully wrote %ld bytes to message queue: %s\n", bytesWritten, string);
	}

    // ����
	free(finalString);
    cJSON_Delete(reply);
    free(string);
}



void handle_SetDCS(cJSON *data) {
    // ���� handle_SetDCS ���߼�
//    xil_printf("CPU1: Handling handle_SetDCS...\r\n");

    SetDCS setDCS;
    cJSON *closedLoop = cJSON_GetObjectItem(data, "ClosedLoop");
     if (closedLoop != NULL) {
         setDCS.ClosedLoop = cJSON_IsTrue(closedLoop);
     } else {
         setDCS.ClosedLoop = true; // Ĭ��ֵ
     }

     //��ȡChns
     cJSON *Chns = cJSON_GetObjectItem(data, "Chns");
     if (Chns == NULL) {
         xil_printf("No Chns found in JSON.\n");
         return;
     }

     int ChnsCount = cJSON_GetArraySize(Chns);
     for (int i = 0; i < ChnsCount; i++) {
         cJSON *Vals = cJSON_GetArrayItem(Chns, i);

         setDCS.Vals[i].Chn	= cJSON_GetObjectItem(Vals, "Chn")->valueint;
         setDCS.Vals[i].UR	= (float)cJSON_GetObjectItem(Vals, "UR")->valuedouble;
         setDCS.Vals[i].U	= (float)cJSON_GetObjectItem(Vals, "U")->valuedouble;
         setDCS.Vals[i].URipple	= (float)cJSON_GetObjectItem(Vals, "URipple")->valuedouble;
         setDCS.Vals[i].IR	= (float)cJSON_GetObjectItem(Vals, "IR")->valuedouble;
         setDCS.Vals[i].I_	= (float)cJSON_GetObjectItem(Vals, "I")->valuedouble;
         setDCS.Vals[i].IRipple	= (float)cJSON_GetObjectItem(Vals, "IRipple")->valuedouble;
     }

     // ��ӡ�����������֤
//     xil_printf("ClosedLoop: %d\r\n", setDCS.ClosedLoop);
     for (int i = 0; i < ChnsDCS; i++) {
         printf("CHn: %d, UR: %.2f, U: %.2f, URipple: %.2f, IR: %.2f, I: %.2f, IRipple: %.2f\r\n",
                    setDCS.Vals[i].Chn,
                    setDCS.Vals[i].UR, setDCS.Vals[i].U, setDCS.Vals[i].URipple,
                    setDCS.Vals[i].IR, setDCS.Vals[i].I_, setDCS.Vals[i].IRipple);
     }

     //�ر�JSON
     ReplyData replyData;
     strcpy(replyData.FunCode, "SetDCS");
     strcpy(replyData.Result, "Success");
     replyData.hasClosedLoop = true;
     replyData.ClosedLoop = setDCS.ClosedLoop;

     // д��ر�ָ������ڴ�
     write_reply_to_shared_memory(&replyData);
}

void handle_SetDCM(cJSON *data) {
    // ���� handle_SetDCM ���߼�
//    xil_printf("CPU1: Handling handle_SetDCM...\r\n");

    SetDCM setDCM;
    //��ȡChns
    cJSON *Chns = cJSON_GetObjectItem(data, "Chns");
    if (Chns == NULL) {
        xil_printf("No Chns found in JSON.\n");
        return;
    }
    int ChnsCount = cJSON_GetArraySize(Chns);

    for (int i = 0; i < ChnsCount; i++){
    	cJSON *Vals = cJSON_GetArrayItem(Chns, i);

    	setDCM.Vals[i].Chn	=	cJSON_GetObjectItem(Vals,"Chn")->valueint;
    	setDCM.Vals[i].UR	=	(float)cJSON_GetObjectItem(Vals, "UR")->valuedouble;
    	setDCM.Vals[i].IR	=	(float)cJSON_GetObjectItem(Vals, "IR")->valuedouble;
    }
    // ��ӡ�����������֤

    for (int i = 0; i < ChnsDCM; i++) {
        printf("CHn: %d, UR: %.2f,IR: %.2f, \r\n",
                   setDCM.Vals[i].Chn,
                   setDCM.Vals[i].UR,
                   setDCM.Vals[i].IR);
    }

    //�ر�JSON
    ReplyData replyData;
    strcpy(replyData.FunCode, "SetDCM");
    strcpy(replyData.Result, "Success");
    replyData.hasClosedLoop = false;
    // д��ر�ָ������ڴ�
    write_reply_to_shared_memory(&replyData);
}

SetACS setACS;
void handle_SetACS(cJSON *data) {
	// ���� handle_SetACS ���߼�
//	xil_printf("CPU1: Handling handle_SetACS...\r\n");

    // ���� ClosedLoop�������������£�������ԭֵ
    cJSON *closedLoop = cJSON_GetObjectItem(data, "ClosedLoop");
    if (closedLoop != NULL) {
        setACS.ClosedLoop = cJSON_IsTrue(closedLoop);
    }

    // ��ȡ vals ����
    cJSON *vals = cJSON_GetObjectItem(data, "vals");
    if (vals == NULL) {
        xil_printf("No vals found in JSON.\n");
        return;
    }

    int valsCount = cJSON_GetArraySize(vals);
	for (int i = 0; i < valsCount; i++) {
		cJSON *val = cJSON_GetArrayItem(vals, i);
		setACS.Vals[i].Line = cJSON_GetObjectItem(val, "Line")->valueint;
		setACS.Vals[i].Chn = cJSON_GetObjectItem(val, "Chn")->valueint;
		setACS.Vals[i].F = (float)cJSON_GetObjectItem(val, "F")->valuedouble;
		setACS.Vals[i].UR = (float)cJSON_GetObjectItem(val, "UR")->valuedouble;
		setACS.Vals[i].U = (float)cJSON_GetObjectItem(val, "U")->valuedouble;
		setACS.Vals[i].PhU = (float)cJSON_GetObjectItem(val, "PhU")->valuedouble;
		setACS.Vals[i].IR = (float)cJSON_GetObjectItem(val, "IR")->valuedouble;
		setACS.Vals[i].I_ = (float)cJSON_GetObjectItem(val, "I")->valuedouble;
		setACS.Vals[i].PhI = (float)cJSON_GetObjectItem(val, "PhI")->valuedouble;

//		cJSON *val = cJSON_GetArrayItem(vals, i);
//		//ֻ������������Ч����
//		cJSON *line = cJSON_GetObjectItem(val, "Line");
//		if(line){
//			setACS.Vals[i].Line = line->valueint;
//			printf("line\n");
//		}
//        cJSON *chn = cJSON_GetObjectItem(val, "Chn");
//        if (chn){
//        	setACS.Vals[i].Chn = chn->valueint;
//        	printf("Chn\n");
//        }
//        cJSON *f = cJSON_GetObjectItem(val, "F");
//        if (f){
//        	setACS.Vals[i].F = (float)f->valuedouble;
//        	printf("F\n");
//        }
//        cJSON *ur = cJSON_GetObjectItem(val, "UR");
//        if (ur){
//        	setACS.Vals[i].UR = (float)ur->valuedouble;
//        	printf("UR\n");
//        }
//        cJSON *u = cJSON_GetObjectItem(val, "U");
//        if (u){
//        	setACS.Vals[i].U = (float)u->valuedouble;
//        	printf("U\n");
//        }
//        cJSON *phU = cJSON_GetObjectItem(val, "PhU");
//        if (phU){
//        	setACS.Vals[i].PhU = (float)phU->valuedouble;
//        	printf("PhU\n");
//        }
//        cJSON *ir = cJSON_GetObjectItem(val, "IR");
//        if (ir){
//        	setACS.Vals[i].IR = (float)ir->valuedouble;
//        	printf("IR\n");
//        }
//        cJSON *i_ = cJSON_GetObjectItem(val, "I");
//        if (i_) {
//        	setACS.Vals[i].I_ = (float)i_->valuedouble;
//        	printf("I\n");
//        }
//        cJSON *phI = cJSON_GetObjectItem(val, "PhI");
//        if (phI){
//        	setACS.Vals[i].PhI = (float)phI->valuedouble;
//        	printf("PhI\n");
//        }
	}

	 // ��ӡ�����������֤
	 xil_printf("ClosedLoop: %d\r\n", setACS.ClosedLoop);
	 for (int i = 0; i < LinesAC*ChnsAC; i++) {
		printf("Line: %d, CHn: %d, F: %.2f, UR: %.2f, U: %.2f, PhU: %.2f, IR: %.2f, I: %.2f, PhI: %.2f\n",
				setACS.Vals[i].Line, setACS.Vals[i].Chn, setACS.Vals[i].F,
				setACS.Vals[i].UR, setACS.Vals[i].U, setACS.Vals[i].PhU,
				setACS.Vals[i].IR, setACS.Vals[i].I_, setACS.Vals[i].PhI);
	 }


	//�ر�JSON   ��ǰ��Ӳ������֮ǰ
	ReplyData replyData;
	strcpy(replyData.FunCode, "SetACS");
	strcpy(replyData.Result, "Success");
	replyData.hasClosedLoop = true;
	replyData.ClosedLoop = setACS.ClosedLoop;
	// д��ر�ָ������ڴ�
	write_reply_to_shared_memory(&replyData);

	/*����ӳ�䵽Ӳ��*/
	Wave_Frequency = setACS.Vals[0].F;						//Ƶ��
	for(int i = 0; i < 4; i++){
		Phase_shift[i]	= setACS.Vals[i].PhU;				//��λ
		Phase_shift[i+4]	= setACS.Vals[i].PhI;
	}
	enable 				= 	0xff;							//ʹ��ͨ�����
	memset(numHarmonics, 0, sizeof(numHarmonics));			//���г��
	memset(harmonics, 0, sizeof(harmonics));
	memset(harmonics_phases, 0, sizeof(harmonics_phases));

	//���ɽ����ź�
	str_wr_bram();

	//�޸Ķ���DA ���η��� ����
	for(int i = 0; i < 4; i++){
		Wave_Amplitude[i] = (float)(setACS.Vals[i].U / setACS.Vals[i].UR) * 100;
		Wave_Amplitude[i+4] = (float)(setACS.Vals[i].I_ / setACS.Vals[i].IR) * 100;
		Wave_Range[i] = voltage_to_output(setACS.Vals[i].UR);
		Wave_Range[i+4] = current_to_output(setACS.Vals[i].IR);
//		printf(" Wave_Amplitude_U=%f\n Wave_Amplitude_I=%f\n Wave_Range_U=%lu\n Wave_Range_I=%lu\n",Wave_Amplitude[i] , Wave_Amplitude[i+4] , Wave_Range[i] , Wave_Range[i+4]);
	}
	//���ƶ���DA
	power_amplifier_control(Wave_Amplitude,Wave_Range);


}

void handle_SetACM(cJSON *data) {
    // ���� handle_SetACM ���߼�
//    xil_printf("CPU1: Handling handle_SetACM...\r\n");

    SetACM setACM;
    int dataCount = cJSON_GetArraySize(data);
    for (int i = 0; i < dataCount; i++){
    	cJSON *Vals = cJSON_GetArrayItem(data, i);

    	setACM.Vals[i].Line	=	cJSON_GetObjectItem(Vals,"Line")->valueint;
    	setACM.Vals[i].Chn	=	cJSON_GetObjectItem(Vals,"Chn")->valueint;
    	setACM.Vals[i].UR	=	(float)cJSON_GetObjectItem(Vals, "UR")->valuedouble;
    	setACM.Vals[i].IR	=	(float)cJSON_GetObjectItem(Vals, "IR")->valuedouble;
    }
    // ��ӡ�����������֤
    for (int i = 0; i < LinesAC*ChnsAC; i++) {
        printf("Line: %d, CHn: %d, UR: %.2f,IR: %.2f, \n",
        		setACM.Vals[i].Line,
				setACM.Vals[i].Chn,
				setACM.Vals[i].UR,
				setACM.Vals[i].IR);
    }

    //�ر�JSON
    ReplyData replyData;
    strcpy(replyData.FunCode, "SetACM");
    strcpy(replyData.Result, "Success");
    replyData.hasClosedLoop = false;
    // д��ر�ָ������ڴ�
    write_reply_to_shared_memory(&replyData);

    //ӳ�䵽Ӳ��

	ADC_ChannelEnable = 1;
	//����ADC
	adc_start();

	sleep(1);

	/************************** FFt*****************************/
    // ������һ��ͨ��
    AnalyzeWaveform(&fundamental_frequency, &fundamental_value, harmonic_info, 0);

    // ������
    printf("CPU1: Fundamental Frequency: %f Hz\n", fundamental_frequency);
	printf("CPU1: Fundamental Value: %f\n", fundamental_value);

	/************************** FFt*****************************/


}

void handle_SetHarm(cJSON *data) {
    // ���� GetFunCodeList ���߼�
//    xil_printf("CPU1: Handling handle_SetHarm...\r\n");
    SetHarm setHarm;

    int index = 0;
    int arraySize = cJSON_GetArraySize(data);
    for (int i = 0; i < arraySize && index < LinesAC * ChnsAC * HarmNumberMax; i++) {
    	cJSON *item = cJSON_GetArrayItem(data, i);
    	if (item == NULL) {
    		continue;
    	}

    	cJSON *line = cJSON_GetObjectItem(item, "Line");
    	cJSON *chn = cJSON_GetObjectItem(item, "Chn");
    	cJSON *hr = cJSON_GetObjectItem(item, "HR");
    	cJSON *u = cJSON_GetObjectItem(item, "U");
    	cJSON *phU = cJSON_GetObjectItem(item, "PhU");
    	cJSON *iField = cJSON_GetObjectItem(item, "I");
    	cJSON *phI = cJSON_GetObjectItem(item, "PhI");

    	if (line && chn && hr && u && phU && iField && phI) {
    		setHarm.Vals[index].Line = line->valueint;
    		setHarm.Vals[index].Chn = chn->valueint;
    		setHarm.Vals[index].HR = hr->valueint;
    		setHarm.Vals[index].U = (float)u->valuedouble;
    		setHarm.Vals[index].PhU = (float)phU->valuedouble;
    		setHarm.Vals[index].I_ = (float)iField->valuedouble;
    		setHarm.Vals[index].PhI = (float)phI->valuedouble;

            printf("Line: %d, Chn: %d, HR: %d, U: %.2f, PhU: %.2f, I: %.2f, PhI: %.2f\n",
                setHarm.Vals[index].Line,
                setHarm.Vals[index].Chn,
                setHarm.Vals[index].HR,
                setHarm.Vals[index].U,
                setHarm.Vals[index].PhU,
                setHarm.Vals[index].I_,
                setHarm.Vals[index].PhI
            );

    		index++;
    	}
    }



    //ӳ�䵽Ӳ�� ����Ҫ�޸ĺ�ddkЭ��һ����
    // ��� numHarmonics, harmonics �� phases ����
    for (int i = 0; i < arraySize; i++) {
        int ch = setHarm.Vals[i].Chn - 1;
        int harmonicIndex = setHarm.Vals[i].HR - 2;

        // ����U
        numHarmonics[ch] = setHarm.Vals[i].HR;
        harmonics[ch][harmonicIndex] = setHarm.Vals[i].U;
        harmonics_phases[ch][harmonicIndex] = setHarm.Vals[i].PhU;
        // ����I
        numHarmonics[ch + 4] = setHarm.Vals[i].HR;
        harmonics[ch + 4][harmonicIndex] = setHarm.Vals[i].I_;
        harmonics_phases[ch + 4][harmonicIndex] = setHarm.Vals[i].PhI;
    }
	//���ɽ����ź�
	str_wr_bram();

    //�ر�JSON
    ReplyData replyData;
    strcpy(replyData.FunCode, "SetHarm");
    strcpy(replyData.Result, "Success");
    replyData.hasClosedLoop = false;
    // д��ر�ָ������ڴ�
    write_reply_to_shared_memory(&replyData);
}

void handle_SetInterHarm(cJSON *data) {
    // ���� handle_SetInterHarm ���߼�
//    xil_printf("CPU1: Handling handle_SetInterHarm...\r\n");
}
void handle_SetDO(cJSON *data) {
    // ���� handle_SetDO ���߼�
//    xil_printf("CPU1: Handling handle_SetDO...\r\n");

    SetDO setDO;

    int dataCount = cJSON_GetArraySize(data);
    for (int i = 0; i < dataCount; i++){
    	cJSON *Vals = cJSON_GetArrayItem(data, i);

    	setDO.Vals[i].Chn		=	cJSON_GetObjectItem(Vals,"Chn")->valueint;
    	setDO.Vals[i].val		=	cJSON_GetObjectItem(Vals,"val")->valueint;
    }
    // ��ӡ�����������֤

    for (int i = 0; i < ChnsBO; i++) {
        printf("CHn: %d, val: %d\n",
        		setDO.Vals[i].Chn,
				setDO.Vals[i].val);
    }

    //ӳ�䵽Ӳ��
	//������
//	Write_Read_Switch(bit_8 , 0xf0000000);//��д������ģ�� ������8��16��24��32λ //8λģʽ�£�0xf0000000Ϊ��4λд1

    //�ر�JSON
    ReplyData replyData;
    strcpy(replyData.FunCode, "SetDO");
    strcpy(replyData.Result, "Success");
    replyData.hasClosedLoop = false;
    // д��ر�ָ������ڴ�
    write_reply_to_shared_memory(&replyData);
}

void handle_StopDCS(cJSON *data) {
	// ���� handle_StopDCS ���߼�
//	xil_printf("CPU1: Handling handle_StopDCS...\r\n");

	//�ر�JSON
	ReplyData replyData;
	strcpy(replyData.FunCode, "StopDCS");
	strcpy(replyData.Result, "Success");
	replyData.hasClosedLoop = false; // ����Ҫ ClosedLoop �ֶ�

	// д��ر�ָ������ڴ�
	write_reply_to_shared_memory(&replyData);
}
void handle_StopAC(cJSON *data) {
	//������/Դ�رգ�ͬʱ������л�����г������г�������
    // ���� handle_StopACS ���߼�
//    xil_printf("CPU1: Handling handle_StopAC...\r\n");

    //ӳ�䵽Ӳ��
    //�ر�DA
	Wave_Frequency = 50;									//Ƶ��
	memset(Phase_shift, 0, sizeof(Phase_shift));			//��ջ�����λ
	enable 				= 	0x00;							//�ر�ͨ�����
	memset(numHarmonics, 0, sizeof(numHarmonics));			//���г��
	memset(harmonics, 0, sizeof(harmonics));				//���г����ֵ
	memset(harmonics_phases, 0, sizeof(harmonics_phases));	//���г����λ
	str_wr_bram();											//���ɽ����ź�
	//�ر�AD
	ADC_ChannelEnable = 0;

	//�ر�JSON
	ReplyData replyData;
	strcpy(replyData.FunCode, "StopAC");
	strcpy(replyData.Result, "Success");
	replyData.hasClosedLoop = false; // ����Ҫ ClosedLoop �ֶ�

	// д��ر�ָ������ڴ�
	write_reply_to_shared_memory(&replyData);
}

void handle_ClearHarm(cJSON *data) {
    // ���� handle_ClearHarm ���߼�
//    xil_printf("CPU1: Handling handle_ClearHarm...\r\n");

    //ӳ�䵽Ӳ��
	memset(numHarmonics, 0, sizeof(numHarmonics));			//���г��
	memset(harmonics, 0, sizeof(harmonics));
	memset(harmonics_phases, 0, sizeof(harmonics_phases));
	//���ɽ����ź�
	str_wr_bram();

	//�ر�JSON
	ReplyData replyData;
	strcpy(replyData.FunCode, "ClearHarm");
	strcpy(replyData.Result, "Success");
	replyData.hasClosedLoop = false; // ����Ҫ ClosedLoop �ֶ�

	// д��ر�ָ������ڴ�
	write_reply_to_shared_memory(&replyData);
}

void handle_ClearInterHarm(cJSON *data) {
    // ���� handle_ClearInterHarm ���߼�
//    xil_printf("CPU1: Handling handle_ClearInterHarm...\r\n");
}

// ����JSON�ַ�����д�빲���ڴ�ĺ���
void write_reply_to_shared_memory(ReplyData *replyData) {

    // ȷ��д����ɣ�ʹ���ڴ�����
    __sync_synchronize();
    // ����JSON����
    cJSON *json = cJSON_CreateObject();
    cJSON_AddStringToObject(json, "FunType", "Reply");
    cJSON_AddStringToObject(json, "FunCode", replyData->FunCode);
    cJSON_AddStringToObject(json, "Result", replyData->Result);

    // ����Data����
    cJSON *data = cJSON_CreateObject();
    if(replyData->hasClosedLoop){
        cJSON_AddBoolToObject(data, "ClosedLoop", replyData->ClosedLoop);
    }
    cJSON_AddItemToObject(json, "Data", data);

    // ��JSON����ת��Ϊ�ַ���
    char *jsonString = cJSON_PrintUnformatted(json);
    if (jsonString == NULL) {
        xil_printf("Failed to print JSON.\n");
        cJSON_Delete(json);
        return;
    }

    // ���ַ�����β����'|'�ַ�
    size_t jsonStringLength = strlen(jsonString);
    char *finalString = (char *)malloc(jsonStringLength + 3); // +3 ��Ϊ��β '|' ����ֹ�� '\0'
    if (finalString == NULL) {
        xil_printf("Failed to allocate memory for final JSON string.\n");
        cJSON_free(jsonString);
        cJSON_Delete(json);
        return;
    }
    snprintf(finalString, jsonStringLength + 3, "|%s|", jsonString);

    // ���ַ���д�빲���ڴ�
    ssize_t bytesWritten = MsgQue_write(finalString,strlen(finalString));
    if (bytesWritten < 0) {
        xil_printf("CPU1:Failed to write to message queue: %ld\n", bytesWritten);
    } else {
//        xil_printf("CPU1:Successfully wrote %ld bytes to message queue: %s\n", bytesWritten, jsonString);
    }

    // �ͷ�JSON�ַ���
    free(finalString);
    cJSON_free(jsonString);
    // ɾ��JSON����
    cJSON_Delete(json);
}

void write_command_to_shared_memory() {
//1.1
//	const char* command = "{"
//			"\"FunType\": \"Cmd\","
//			"\"FunCode\": \"GetFunCodeList\""
//			"}";

//1.2
//	const char* command = "{"
//			"\"FunType\": \"Cmd\","
//			"\"FunCode\": \"GetDevBaseInfo\""
//			"}";

//1.3
//	const char* command = "{"
//			"\"FunType\": \"Cmd\","
//			"\"FunCode\": \"GetDevState\""
//			"}";

//1.5
//	const char* command = "{"
//			"\"FunType\": \"Cmd\","
//			"\"FunCode\": \"SetReportEnable\","
//			"\"Data\": {"
//			"\"BaseDataAC\": true,"
//			"\"HarmData\": true,"
//			"\"InterHarmData\": false,"
//			"\"BaseDataDC\": false,"
//			"\"BaseDataIO\": false,"
//			"\"DISOE\": false,"
//			"\"VMData\": false"
//			"}"
//			"}";

//3.1.1
//    const char* command = "{"
//        "\"FunType\": \"Cmd\","
//        "\"FunCode\": \"SetDCS\","
//        "\"Data\": {"
//            "\"ClosedLoop\": true,"
//            "\"Chns\": ["
//                "{\"Chn\": 1, \"UR\": 57.7, \"U\": 57.7, \"URipple\": 0.01, \"IR\": 1.1, \"I\": 1.1, \"IRipple\": 0.01},"
//                "{\"Chn\": 2, \"UR\": 57.7, \"U\": 57.7, \"URipple\": 0.02, \"IR\": 2.2, \"I\": 2.2, \"IRipple\": 0.01},"
//                "{\"Chn\": 3, \"UR\": 57.7, \"U\": 57.7, \"URipple\": 0.03, \"IR\": 3.3, \"I\": 3.3, \"IRipple\": 0.01},"
//                "{\"Chn\": 4, \"UR\": 57.7, \"U\": 57.7, \"URipple\": 0.04, \"IR\": 4.4, \"I\": 4.4, \"IRipple\": 0.01}"
//            "]"
//        "}"
//    "}";

//3.1.2
//    const char* command = "{"
//        "\"FunType\": \"Cmd\","
//        "\"FunCode\": \"StopDCS\""
//    "}";

//3.2.1
//	    const char* command = "{"
//	        "\"FunType\": \"Cmd\","
//	        "\"FunCode\": \"SetDCM\","
//	        "\"Data\": ["
//	    		"{\"Chn\": 1, \"UR\": 100.0, \"IR\": 1.1},"
//	    		"{\"Chn\": 2, \"UR\": 57.7,  \"IR\": 2.2},"
//	    		"{\"Chn\": 3, \"UR\": 57.7,  \"IR\": 3.3},"
//	    		"{\"Chn\": 4, \"UR\": 57.7,  \"IR\": 4.4}"
//	        "]"
//	    "}";

//3.3.1
//    const char* command = "{"
//        "\"FunType\": \"Cmd\","
//        "\"FunCode\": \"SetACS\","
//        "\"Data\": {"
//            "\"ClosedLoop\": true,"
//            "\"vals\": ["
//                "{\"Line\": 1, \"Chn\": 1, \"F\": 60.0, \"UR\": 57.7, \"U\": 57.7, \"PhU\": 0, \"IR\": 5.1, \"I\": 1.1, \"PhI\": 30.4},"
//                "{\"Line\": 1, \"Chn\": 2, \"F\": 60.0, \"UR\": 57.7, \"U\": 57.7, \"PhU\": 120, \"IR\": 5, \"I\": 2, \"PhI\": 120},"
//                "{\"Line\": 1, \"Chn\": 3, \"F\": 60.0, \"UR\": 57.7, \"U\": 57.7, \"PhU\": 240, \"IR\": 5, \"I\": 3, \"PhI\": 240},"
//                "{\"Line\": 1, \"Chn\": 4, \"F\": 60.0, \"UR\": 57.7, \"U\": 10, \"PhU\": 0, \"IR\": 5, \"I\": 4, \"PhI\": 0},"
//                "{\"Line\": 2, \"Chn\": 1, \"F\": 60.0, \"UR\": 57.7, \"U\": 57.7, \"PhU\": 0, \"IR\": 5, \"I\": 4, \"PhI\": 0},"
//                "{\"Line\": 2, \"Chn\": 2, \"F\": 60.0, \"UR\": 57.7, \"U\": 57.7, \"PhU\": 120, \"IR\": 5, \"I\": 3, \"PhI\": 120},"
//                "{\"Line\": 2, \"Chn\": 3, \"F\": 60.0, \"UR\": 57.7, \"U\": 57.7, \"PhU\": 240, \"IR\": 5, \"I\": 2, \"PhI\": 240},"
//                "{\"Line\": 2, \"Chn\": 4, \"F\": 60.0, \"UR\": 57.7, \"U\": 20, \"PhU\": 0, \"IR\": 5, \"I\": 1, \"PhI\": 0}"
//            "]"
//        "}"
//    "}";

//3.3.2
//    const char* command = "{"
//        "\"FunType\": \"Cmd\","
//        "\"FunCode\": \"SetACM\","
//        "\"Data\": ["
//    		"{\"Line\": 1, \"Chn\": 1, \"UR\": 100.0, \"IR\": 1.1},"
//    		"{\"Line\": 1, \"Chn\": 2, \"UR\": 57.7,  \"IR\": 2.2},"
//    		"{\"Line\": 1, \"Chn\": 3, \"UR\": 57.7,  \"IR\": 3.3},"
//    		"{\"Line\": 1, \"Chn\": 4, \"UR\": 57.7,  \"IR\": 4.4},"
//    		"{\"Line\": 2, \"Chn\": 1, \"UR\": 100.0, \"IR\": 1.1},"
//    		"{\"Line\": 2, \"Chn\": 2, \"UR\": 57.7,  \"IR\": 2.2},"
//    		"{\"Line\": 2, \"Chn\": 3, \"UR\": 57.7,  \"IR\": 3.3},"
//    		"{\"Line\": 2, \"Chn\": 4, \"UR\": 57.7,  \"IR\": 4.4}"
//        "]"
//    "}";

//3.3.3
//	const char* command = "{"
//	    "\"FunType\": \"Cmd\","
//	    "\"FunCode\": \"SetHarm\","
//	    "\"Data\": ["
//	        "{\"Line\": 1, \"Chn\": 1, \"HR\": 2, \"U\": 0.0, \"PhU\": 0.0, \"I\": 0.1, \"PhI\": 0},"
//	        "{\"Line\": 1, \"Chn\": 1, \"HR\": 3, \"U\": 0.0, \"PhU\": 60.0, \"I\": 0.1, \"PhI\": 60.0},"
//			"{\"Line\": 1, \"Chn\": 1, \"HR\": 4, \"U\": 0.0, \"PhU\": 120.0, \"I\": 0.1, \"PhI\": 120.0},"
//			"{\"Line\": 1, \"Chn\": 1, \"HR\": 5, \"U\": 0.0, \"PhU\": 180.0, \"I\": 0.1, \"PhI\": 180.0},"
//			"{\"Line\": 1, \"Chn\": 2, \"HR\": 2, \"U\": 0.1, \"PhU\": 0, \"I\": 0.1, \"PhI\": 0},"
//			"{\"Line\": 1, \"Chn\": 2, \"HR\": 3, \"U\": 0.1, \"PhU\": 60.0, \"I\": 0.1, \"PhI\": 60.0},"
//			"{\"Line\": 1, \"Chn\": 2, \"HR\": 4, \"U\": 0.1, \"PhU\": 120.0, \"I\": 0.1, \"PhI\": 120.0},"
//			"{\"Line\": 1, \"Chn\": 2, \"HR\": 5, \"U\": 0.1, \"PhU\": 180.0, \"I\": 0.1, \"PhI\": 180.0},"
//			"{\"Line\": 1, \"Chn\": 3, \"HR\": 2, \"U\": 0.1, \"PhU\": 0, \"I\": 0.1, \"PhI\": 0},"
//			"{\"Line\": 1, \"Chn\": 3, \"HR\": 3, \"U\": 0.1, \"PhU\": 60.0, \"I\": 0.1, \"PhI\": 60.0},"
//			"{\"Line\": 1, \"Chn\": 3, \"HR\": 4, \"U\": 0.1, \"PhU\": 120.0, \"I\": 0.1, \"PhI\": 120.0},"
//			"{\"Line\": 1, \"Chn\": 3, \"HR\": 5, \"U\": 0.1, \"PhU\": 180.0, \"I\": 0.1, \"PhI\": 180.0},"
//	        "{\"Line\": 1, \"Chn\": 4, \"HR\": 2, \"U\": 0.1, \"PhU\": 0, \"I\": 0.0, \"PhI\": 0},"
//	        "{\"Line\": 1, \"Chn\": 4, \"HR\": 3, \"U\": 0.1, \"PhU\": 60.0, \"I\": 0.0, \"PhI\": 0.0},"
//	        "{\"Line\": 1, \"Chn\": 4, \"HR\": 4, \"U\": 0.1, \"PhU\": 120.0, \"I\": 0.0, \"PhI\": 0.0},"
//	        "{\"Line\": 1, \"Chn\": 4, \"HR\": 5, \"U\": 0.1, \"PhU\": 180.0, \"I\": 0.3, \"PhI\": 0.0}"
//	    "]"
//	"}";

//3.3.4
//	const char* command = "{"
//			"\"FunType\": \"Cmd\","
//			"\"FunCode\": \"ClearHarm\""
//			"}";


//3.3.7
//	const char* command = "{"
//			"\"FunType\": \"Cmd\","
//			"\"FunCode\": \"StopAC\""
//			"}";

//3.4
//	const char* command = "{"
//			"\"FunType\": \"Cmd\","
//			"\"FunCode\": \"SetDO\","
//			"\"Data\": ["
//			"{\"Chn\": 1, \"val\": 0},"
//			"{\"Chn\": 2, \"val\": 0},"
//			"{\"Chn\": 3, \"val\": 0},"
//			"{\"Chn\": 4, \"val\": 0},"
//			"{\"Chn\": 5, \"val\": 1},"
//			"{\"Chn\": 6, \"val\": 1},"
//			"{\"Chn\": 7, \"val\": 1},"
//			"{\"Chn\": 8, \"val\": 1}"
//			"]"
//			"}";


    // ���ַ���д�빲���ڴ�

    xil_printf("Command written to shared memory.\n");
}


size_t calculate_dynamic_payload_size(ReportEnableStatus ReportStatus) {
    size_t payload_size = 0;
    size_t header_size = sizeof(u32) * 2;

    if (ReportStatus.BaseDataAC) {
        payload_size += header_size + sizeof(LineAC);
//        printf("BaseDataAC size: %zu\n", header_size + sizeof(LineAC));
    } else {
        payload_size += header_size;
//        printf("BaseDataAC header only: %zu\n", header_size);
    }

    if (ReportStatus.HarmData) {
        payload_size += header_size + sizeof(LineHarm);
//        printf("HarmData size: %zu\n", header_size + sizeof(LineHarm));
    } else {
        payload_size += header_size;
//        printf("HarmData header only: %zu\n", header_size);
    }

    if (ReportStatus.DI) {
        payload_size += header_size + sizeof(LineDI);
//        printf("DI size: %zu\n", header_size + sizeof(LineDI));
    } else {
        payload_size += header_size;
//        printf("DI header only: %zu\n", header_size);
    }

    if (ReportStatus.DO) {
        payload_size += header_size + sizeof(LineDO);
//        printf("DO size: %zu\n", header_size + sizeof(LineDO));
    } else {
        payload_size += header_size;
//        printf("DO header only: %zu\n", header_size);
    }

    if (ReportStatus.DISOE) {
        payload_size += header_size + sizeof(LineDisoe);
//        printf("DISOE size: %zu\n", header_size + sizeof(LineDisoe));
    } else {
        payload_size += header_size;
//        printf("DISOE header only: %zu\n", header_size);
    }

//    printf("Total dynamic payload size: %zu\n", payload_size);
    return payload_size;
}




/*
 * �ر�UDP�ṹ�嶥�㺯��
 */
//��ʼ��ʹ��״̬�ṹ��
void ReportUDP_Structure(ReportEnableStatus ReportStatus){
    UDPPacket udpPacket;

    LineAC lineAC;
    LineHarm lineHarm;
    LineDI lineDI;
    LineDO lineDO;
    LineDisoe lineDisoe;

    // ��ʼ�����ݽṹ��
    initLineAC(&lineAC);
    initLineHarm(&lineHarm);
    initLineDI(&lineDI);
    initLineDO(&lineDO);
    initLineDisoe(&lineDisoe);

    // ��̬���� payload ��С
    size_t dynamic_payload_size = calculate_dynamic_payload_size(ReportStatus);

    /*дUDP�ṹ��֡ͷ��*/
    memcpy(udpPacket.syncHeader, (char[]){0xD1, 0xD2, 0xD3, 0xD4}, 4);  // ͬ��ͷ
    udpPacket.dataLength1 = dynamic_payload_size;						// �������ܳ���
    udpPacket.dataLength2 = dynamic_payload_size;						//�ظ�һ�� �������ܳ���
    udpPacket.versionInfo = 1;                                          // �汾��Ϣ
    memset(udpPacket.reserved, 0, 3);                                   // ����

    /*���������*/
    char* payload_ptr = udpPacket.payload;
    u32 structType;
    u32 structLength;

    // LineAC
    structType = BaseDataAC;
    structLength = ReportStatus.BaseDataAC ? sizeof(LineAC) : 0;
    memcpy(payload_ptr, &structType, sizeof(structType));
    payload_ptr += sizeof(structType);
    memcpy(payload_ptr, &structLength, sizeof(structLength));
    payload_ptr += sizeof(structLength);
    if (ReportStatus.BaseDataAC) {
        memcpy(payload_ptr, &lineAC, sizeof(LineAC));
        payload_ptr += sizeof(LineAC);
    }

    // LineHarm
    structType = HarmData;
    structLength = ReportStatus.HarmData ? sizeof(LineHarm) : 0;
    memcpy(payload_ptr, &structType, sizeof(structType));
    payload_ptr += sizeof(structType);
    memcpy(payload_ptr, &structLength, sizeof(structLength));
    payload_ptr += sizeof(structLength);
    if (ReportStatus.HarmData) {
        memcpy(payload_ptr, &lineHarm, sizeof(LineHarm));
        payload_ptr += sizeof(LineHarm);
    }

    // LineDI
    structType = DI;
    structLength = ReportStatus.DI ? sizeof(LineDI) : 0;
    memcpy(payload_ptr, &structType, sizeof(structType));
    payload_ptr += sizeof(structType);
    memcpy(payload_ptr, &structLength, sizeof(structLength));
    payload_ptr += sizeof(structLength);
    if (ReportStatus.DI) {
        memcpy(payload_ptr, &lineDI, sizeof(LineDI));
        payload_ptr += sizeof(LineDI);
    }

    // LineDO
    structType = DO;
    structLength = ReportStatus.DO ? sizeof(LineDO) : 0;
    memcpy(payload_ptr, &structType, sizeof(structType));
    payload_ptr += sizeof(structType);
    memcpy(payload_ptr, &structLength, sizeof(structLength));
    payload_ptr += sizeof(structLength);
    if (ReportStatus.DO) {
        memcpy(payload_ptr, &lineDO, sizeof(LineDO));
        payload_ptr += sizeof(LineDO);
    }

    // LineDisoe
    structType = DISOE;
    structLength = ReportStatus.DISOE ? sizeof(LineDisoe) : 0;
    memcpy(payload_ptr, &structType, sizeof(structType));
    payload_ptr += sizeof(structType);
    memcpy(payload_ptr, &structLength, sizeof(structLength));
    payload_ptr += sizeof(structLength);
    if (ReportStatus.DISOE) {
        memcpy(payload_ptr, &lineDisoe, sizeof(LineDisoe));
        payload_ptr += sizeof(LineDisoe);
    }

    /* дUDP֡β*/
    memcpy(payload_ptr, (char[]){0xE1, 0xE2, 0xE3, 0xE4}, 4); // ������
    payload_ptr += 4 * sizeof(u8);

    // д UDP ���ݵ������ڴ�
    // ���ù����ڴ����һ���ֽ�Ϊ 1�����ռ��
    uint32_t last_byte_addr = UDP_ADDRESS + UDP_MEM_SIZE - 4;  // �����ڴ����һ���ֵ�ַ
    Xil_Out32(last_byte_addr, 1);
    Xil_DCacheFlushRange((INTPTR)last_byte_addr, sizeof(u32));
    write_UDP_to_shared_memory(UDP_ADDRESS, &udpPacket, 16 + dynamic_payload_size + 4);
    // ���ù����ڴ����һ���ֽ�Ϊ 0����ǿ���
    Xil_Out32(last_byte_addr, 0);
    Xil_DCacheFlushRange((INTPTR)last_byte_addr, sizeof(u32));

    // ��ӡ������Ϣ
//    printf("dynamic_payload_size: %zu bytes\n", dynamic_payload_size);
//    printf("UDP_PACKET_SIZE: %d bytes\n", sizeof(UDPPacket));
    // printf("CPU1: UDP written to memory at: 0x%X\n", UDP_ADDRESS);
}


// Function to initialize LineAC
void initLineAC(LineAC *lineAC) {
    for (int i = 0; i < ChnsAC; i++) {
        lineAC->ur[i] = (double)setACS.Vals[i].UR;
        lineAC->ir[i] = (double)setACS.Vals[i].IR;
        lineAC->u[i] = (double)setACS.Vals[i].U;
        lineAC->i[i] = (double)setACS.Vals[i].I_;
        lineAC->phu[i] = (double)setACS.Vals[i].PhU;
        lineAC->phi[i] = (double)setACS.Vals[i].PhI;
        lineAC->p[i] = 7.0 ;
        lineAC->q[i] = 8.0 ;
        lineAC->pf[i] = 9.0 ;
        lineAC->f[i] = 10.0 ;
        lineAC->thdu[i] = 11.0 ;
        lineAC->thdi[i] = 12.0 ;
    }
    lineAC->totalP = 100.0;
    lineAC->totalQ = 200.0;
    lineAC->totalPF = 90.0;
}

// Function to initialize LineHarm
void initLineHarm(LineHarm *lineHarm) {
    for (int i = 0; i < ChnsAC; i++) {
        for (int j = 0; j < HarmNumberMax; j++) {
            lineHarm->harm[i].u[j] = 10.0 ;
            lineHarm->harm[i].i[j] = 20.0 ;
            lineHarm->harm[i].phu[j] = 30.0 ;
            lineHarm->harm[i].phi[j] = 40.0 ;
            lineHarm->harm[i].p[j] = 50.0 ;
            lineHarm->harm[i].q[j] = 60.0 ;
        }
        lineHarm->harm[i].totalP = 300.0;
        lineHarm->harm[i].totalQ = 400.0;
    }
}
void initLineDI(LineDI *lineDI) {
    for (int i = 0; i < ChnsDI; i++) {
    	lineDI->DI[i].v = 1;
    }
}

void initLineDO(LineDO *lineDO) {
    for (int i = 0; i < ChnsDO; i++) {
    	lineDO->DO[i].v = 0;
    }
}

void initLineDisoe(LineDisoe *lineDisoe) {
    for (int i = 0; i < DisoeMsgNum; i++) {
    	lineDisoe->DISOE[i].Chn = i;
    	lineDisoe->DISOE[i].Val = 1;
    	lineDisoe->DISOE[i].MS = 999;
    	lineDisoe->DISOE[i].TIME = 9999;
    }
}

// Function to write data to shared memory
void write_UDP_to_shared_memory(UINTPTR base_addr, void* data, size_t size) {
    u32* data_ptr = (u32*)data;
    size_t words = size / 4;

    for (size_t i = 0; i < words; i++) {
        Xil_Out32(base_addr + (i * 4), data_ptr[i]);
    }
    Xil_DCacheFlushRange((INTPTR)UDP_ADDRESS, size);
}



