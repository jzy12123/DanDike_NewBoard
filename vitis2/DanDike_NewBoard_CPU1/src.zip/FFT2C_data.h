/*
 * File: FFT2C_data.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 31-May-2024 16:43:36
 */

#ifndef FFT2C_DATA_H
#define FFT2C_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#endif
/*
 * File trailer for FFT2C_data.h
 *
 * [EOF]
 */
