/*
 * File: FFT2C_terminate.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 31-May-2024 16:43:36
 */

#ifndef FFT2C_TERMINATE_H
#define FFT2C_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void FFT2C_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for FFT2C_terminate.h
 *
 * [EOF]
 */
