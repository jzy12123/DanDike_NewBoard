//==================================================================================================//
//  Revision Time:                                                                                  //
//        2025��5��11�ա�                                                                           //
//  Founctions��                                                                                    //
//        ��ʱ��+����+��������д�ȣ��书�ܵľ�����������Ӧ.v�ļ����ļ�ͷ��                          //
//--------------------------------------------------------------------------------------------------//
// д�Ĵ����ĺ���|slv_reg0 slv_reg1 slv_reg2 slv_reg3 slv_reg4 slv_reg5 slv_reg6 slv_reg7 ��ע      // 
//--------------------------------------------------------------------------------------------------//          
//	 pre_year    |[17:10]                                                                 BCD��     //
//   pre_month   |         [17:13]                                                        BCD��     //
//   pre_day     |         [12:7]                                                         BCD��     //
//   pre_week    |         [6:0]                                                         ������     //
//   pre_yearday |[9:0]                                                                   BCD��     //
//	 pre_hour    |                  [19:14]                                               BCD��     //
//   pre_minute  |                  [13:7]                                                BCD��     //
//   pre_second  |                  [6:0]                                                 BCD��     //
//	 wr_date     |                           [0]                                        Ԥ������    //
//   wr_time     |                                   [0]                                 Ԥ��ʱ��   //         
//   bm_encode_en|                                            [0]                     ����B�����   //
//   bm_decode_en|                                                      [0]           ����B��Уʱ   //
//   pps_clr_en  |                                                               [0] ������������� //
//--------------------------------------------------------------------------------------------------//		
// ���Ĵ����ĺ��壺                                                                                 //
//  slv_reg0�� {14'd0, bm_year[7:0],   bm_yearday[9:0]};                                            //
//  slv_reg1�� {12'd0, bm_hour[5:0],   bm_minute[6:0],     bm_second[6:0]};                         //
//  slv_reg2�� {15'd0, bm_daysec[16:0]};                                                            //
//                                                                                                  //
//  slv_reg3�� {14'd0, curr_year[7:0],  curr_yearday[9:0]};                                         //
//  slv_reg4�� {14'd0, curr_month[4:0], curr_day[5:0],    curr_week[6:0]};                          //
//  slv_reg5�� {12'd0, curr_hour[5:0],  curr_minute[6:0], curr_second[6:0]};                        //
//  slv_reg6�� {15'd0, curr_daysec[16:0]};                                                          //
//  slv_reg7�� {8'd0,  curr_subsec[23:0]};                                                          // 
//--------------------------------------------------------------------------------------------------//
//  д�Ĵ���	        | slv_reg8	slv_reg9	slv_reg10	slv_reg11	slv_reg12	slv_reg13       // 
//--------------------------------------------------------------------------------------------------//
//  onoff    byte_num   | [18:16]					                                                //
//	         rw_modes   | [31:30]                                                                   //	
//	         start	    | [24]	                                                                    //				
//           din	    |					                                         [31:0]         //
//                      |                                                                           //
//wrserial	ld1595_en   | [0]                                                                       //					
//       	ld595_en    | [1]                                                                       //					
// 	        start	    | [8]                                                                       //					
// 	        din0	    |          [31:0]                                                           //				
// 	        din1	    |	                   [31:0]                                               //			
// 	        din2	    |		                           [31:0]	                                //	
// 	        din3	    |			                                   [31:0]                       //	
//                      |                                                                           //                
// rdserial	enable	    | [9]	                                                                    //
//--------------------------------------------------------------------------------------------------//				
//���Ĵ���          	| slv_reg8	slv_reg9	slv_reg10	slv_reg11	slv_reg12	slv_reg13       //
//--------------------------------------------------------------------------------------------------//
//onoff	   onoff_done	|  [31]					                                                    //
//      	dout		|            [31:0]				                                            //
//         latch_hour   |                                   [19:14]                                 //
//         latch_minute |                                   [13:7]                                  //
//         latch_second |                                   [6:0]                                   //
//         latch_daysec |                                                 [16:0]                    //
//         latch_subsec |                                                             [23:0]        //
//wrserial wrserial_done|  [15]					                                                    //
//rdserial	dataout		|	                     [7:0]			                                    //
//--------------------------------------------------------------------------------------------------//
//  ע��                                                                                            //
//     ��8·���ϵ�Ӳ����·�У�û�����ö�����źš��Ӷ�ʹ��=>�������Ҫ��Լ0.5us��ʱ�䡣             //
//==================================================================================================//

`timescale 1 ns / 1 ps

	module stimer_onoff_pa_rw_AXI #
	(
		// Users to add parameters here

		// User parameters ends
		// Do not modify the parameters beyond this line

		// Width of S_AXI data bus
		parameter integer C_S_AXI_DATA_WIDTH	= 32,
		// Width of S_AXI address bus
		parameter integer C_S_AXI_ADDR_WIDTH	= 6
	)
	(
		// Users to add ports here
        // FPGA interface
    	input  wire   clk_10MHz,      // ��10MHz�ĺ��¾���
		input wire   CLK25MHz,        // ��25MHzʱ��
		input wire   CLK25MHz_RSTN,	  // 25MHzʱ�ӵĵ�
				
	   // FPGA �ⲿ�˿�	 
       // soft timer	   
		input  wire   pps_gps   ,     // ����GPS����ͬ���źţ�����300ms
		input  wire   pps_in    ,     // ������ʱ��ֻҪ����ͬ��
		input  wire   irig_b_in ,     // B�������źš������豸ͬ����Ҫ����ʾ��ʱ���̼���ʱ�ɹ�����
		output wire   irig_b_out,     // B�������һֱ�ڷ���   
		output wire   pps_50    ,     // pps���������50%ռ�ձȣ����ڼ���ڲ�ʱ���ȶ���	
		
		//onoff control interface
		output  wire onoff_cs,
		output  wire onoff_sclk,
		output  wire onoff_sdo,		
		input   wire onoff_sdi,
		output  wire onoff_done,       // �ж��ź�
		
		//power amplifier config interface
		output  wire wrserial_load,
		output  wire wrserial_sclk,
		output  wire wrserial_sdo,
		output  wire wrserial_done,     //�ж��ź�
		
		//read 8' fail-signals
		output  wire rdserial_load,    
		output  wire rdserial_sclk,
		input   wire rdserial_sdi,

       // ��ʱ�Ӷ�Ӧ���ж������ź�
	    output  wire   pps_gps2cpu,   // 3��pps�źţ�����������ȷ��ʱ
	    output  wire   pps_in2cpu ,   // �����ⲿ����pps_in�ĸ�����ʱ�ź�
        output  wire   pps_bm2cpu ,   // B�����õ���pps�ź�
	    output  wire   bm_syn_end ,   // B�����ɹ������Զ��������ʱ�ӵ�ͬ��	
		output  wire   date_update,   // 00:00:00���ˣ�����CPU������������		
		
		// User ports ends
		// Do not modify the ports beyond this line

		// Global Clock Signal
		input wire  S_AXI_ACLK,       //100MHz
		// Global Reset Signal. This Signal is Active LOW
		input wire  S_AXI_ARESETN,    //100MHzʱ�ӵĵ�
		// Write address (issued by master, acceped by Slave)
		input wire [C_S_AXI_ADDR_WIDTH-1 : 0] S_AXI_AWADDR,
		// Write channel Protection type. This signal indicates the
    		// privilege and security level of the transaction, and whether
    		// the transaction is a data access or an instruction access.
		input wire [2 : 0] S_AXI_AWPROT,
		// Write address valid. This signal indicates that the master signaling
    		// valid write address and control information.
		input wire  S_AXI_AWVALID,
		// Write address ready. This signal indicates that the slave is ready
    		// to accept an address and associated control signals.
		output wire  S_AXI_AWREADY,
		// Write data (issued by master, acceped by Slave) 
		input wire [C_S_AXI_DATA_WIDTH-1 : 0] S_AXI_WDATA,
		// Write strobes. This signal indicates which byte lanes hold
    		// valid data. There is one write strobe bit for each eight
    		// bits of the write data bus.    
		input wire [(C_S_AXI_DATA_WIDTH/8)-1 : 0] S_AXI_WSTRB,
		// Write valid. This signal indicates that valid write
    		// data and strobes are available.
		input wire  S_AXI_WVALID,
		// Write ready. This signal indicates that the slave
    		// can accept the write data.
		output wire  S_AXI_WREADY,
		// Write response. This signal indicates the status
    		// of the write transaction.
		output wire [1 : 0] S_AXI_BRESP,
		// Write response valid. This signal indicates that the channel
    		// is signaling a valid write response.
		output wire  S_AXI_BVALID,
		// Response ready. This signal indicates that the master
    		// can accept a write response.
		input wire  S_AXI_BREADY,
		// Read address (issued by master, acceped by Slave)
		input wire [C_S_AXI_ADDR_WIDTH-1 : 0] S_AXI_ARADDR,
		// Protection type. This signal indicates the privilege
    		// and security level of the transaction, and whether the
    		// transaction is a data access or an instruction access.
		input wire [2 : 0] S_AXI_ARPROT,
		// Read address valid. This signal indicates that the channel
    		// is signaling valid read address and control information.
		input wire  S_AXI_ARVALID,
		// Read address ready. This signal indicates that the slave is
    		// ready to accept an address and associated control signals.
		output wire  S_AXI_ARREADY,
		// Read data (issued by slave)
		output wire [C_S_AXI_DATA_WIDTH-1 : 0] S_AXI_RDATA,
		// Read response. This signal indicates the status of the
    		// read transfer.
		output wire [1 : 0] S_AXI_RRESP,
		// Read valid. This signal indicates that the channel is
    		// signaling the required read data.
		output wire  S_AXI_RVALID,
		// Read ready. This signal indicates that the master can
    		// accept the read data and response information.
		input wire  S_AXI_RREADY
	);

	// AXI4LITE signals
	reg [C_S_AXI_ADDR_WIDTH-1 : 0] 	axi_awaddr;
	reg  	axi_awready;
	reg  	axi_wready;
	reg [1 : 0] 	axi_bresp;
	reg  	axi_bvalid;
	reg [C_S_AXI_ADDR_WIDTH-1 : 0] 	axi_araddr;
	reg  	axi_arready;
	reg [C_S_AXI_DATA_WIDTH-1 : 0] 	axi_rdata;
	reg [1 : 0] 	axi_rresp;
	reg  	axi_rvalid;

	// Example-specific design signals
	// local parameter for addressing 32 bit / 64 bit C_S_AXI_DATA_WIDTH
	// ADDR_LSB is used for addressing 32/64 bit registers/memories
	// ADDR_LSB = 2 for 32 bits (n downto 2)
	// ADDR_LSB = 3 for 64 bits (n downto 3)
	localparam integer ADDR_LSB = (C_S_AXI_DATA_WIDTH/32) + 1;
	localparam integer OPT_MEM_ADDR_BITS = 3;
	//----------------------------------------------
	//-- Signals for user logic register space example
	//------------------------------------------------
	//-- Number of Slave Registers 8
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg0;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg1;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg2;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg3;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg4;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg5;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg6;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg7;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg8;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg9;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg10;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg11;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg12;
	reg [C_S_AXI_DATA_WIDTH-1:0]	slv_reg13;	
	wire	 slv_reg_rden;
	wire	 slv_reg_wren;
	reg [C_S_AXI_DATA_WIDTH-1:0]    reg_data_out;
	integer	 byte_index;
	reg	 aw_en;

	// I/O Connections assignments

	assign S_AXI_AWREADY	= axi_awready;
	assign S_AXI_WREADY	= axi_wready;
	assign S_AXI_BRESP	= axi_bresp;
	assign S_AXI_BVALID	= axi_bvalid;
	assign S_AXI_ARREADY	= axi_arready;
	assign S_AXI_RDATA	= axi_rdata;
	assign S_AXI_RRESP	= axi_rresp;
	assign S_AXI_RVALID	= axi_rvalid;
	// Implement axi_awready generation
	// axi_awready is asserted for one S_AXI_ACLK clock cycle when both
	// S_AXI_AWVALID and S_AXI_WVALID are asserted. axi_awready is
	// de-asserted when reset is low.

	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      axi_awready <= 1'b0;
	      aw_en <= 1'b1;
	    end 
	  else
	    begin    
	      if (~axi_awready && S_AXI_AWVALID && S_AXI_WVALID && aw_en)
	        begin
	          // slave is ready to accept write address when 
	          // there is a valid write address and write data
	          // on the write address and data bus. This design 
	          // expects no outstanding transactions. 
	          axi_awready <= 1'b1;
	          aw_en <= 1'b0;
	        end
	        else if (S_AXI_BREADY && axi_bvalid)
	            begin
	              aw_en <= 1'b1;
	              axi_awready <= 1'b0;
	            end
	      else           
	        begin
	          axi_awready <= 1'b0;
	        end
	    end 
	end       

	// Implement axi_awaddr latching
	// This process is used to latch the address when both 
	// S_AXI_AWVALID and S_AXI_WVALID are valid. 

	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      axi_awaddr <= 0;
	    end 
	  else
	    begin    
	      if (~axi_awready && S_AXI_AWVALID && S_AXI_WVALID && aw_en)
	        begin
	          // Write Address latching 
	          axi_awaddr <= S_AXI_AWADDR;
	        end
	    end 
	end       

	// Implement axi_wready generation
	// axi_wready is asserted for one S_AXI_ACLK clock cycle when both
	// S_AXI_AWVALID and S_AXI_WVALID are asserted. axi_wready is 
	// de-asserted when reset is low. 

	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      axi_wready <= 1'b0;
	    end 
	  else
	    begin    
	      if (~axi_wready && S_AXI_WVALID && S_AXI_AWVALID && aw_en )
	        begin
	          // slave is ready to accept write data when 
	          // there is a valid write address and write data
	          // on the write address and data bus. This design 
	          // expects no outstanding transactions. 
	          axi_wready <= 1'b1;
	        end
	      else
	        begin
	          axi_wready <= 1'b0;
	        end
	    end 
	end       

	// Implement memory mapped register select and write logic generation
	// The write data is accepted and written to memory mapped registers when
	// axi_awready, S_AXI_WVALID, axi_wready and S_AXI_WVALID are asserted. Write strobes are used to
	// select byte enables of slave registers while writing.
	// These registers are cleared when reset (active low) is applied.
	// Slave register write enable is asserted when valid address and data are available
	// and the slave is ready to accept the write address and write data.
	assign slv_reg_wren = axi_wready && S_AXI_WVALID && axi_awready && S_AXI_AWVALID;

	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      slv_reg0 <= 0;
	      slv_reg1 <= 0;
	      slv_reg2 <= 0;
	      slv_reg3 <= 0;
	      slv_reg4 <= 0;
	      slv_reg5 <= 0;
	      slv_reg6 <= 0;
	      slv_reg7 <= 0;
	      slv_reg8 <= 0;
	      slv_reg9 <= 0;
	      slv_reg10<= 0;
	      slv_reg11<= 0;
	      slv_reg12<= 0;
	      slv_reg13<= 0;		  
	    end 
	  else begin
	    if (slv_reg_wren)
	      begin
	        case ( axi_awaddr[ADDR_LSB+OPT_MEM_ADDR_BITS:ADDR_LSB] )
	          4'h0:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 0
	                slv_reg0[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h1:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 1
	                slv_reg1[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h2:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 2
	                slv_reg2[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h3:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 3
	                slv_reg3[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h4:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 4
	                slv_reg4[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h5:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 5
	                slv_reg5[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h6:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 6
	                slv_reg6[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h7:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 7
	                slv_reg7[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end  
	          4'h8:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 8
	                slv_reg8[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end 
	          4'h9:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 9
	                slv_reg9[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end 
	          4'd10:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 10
	                slv_reg10[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end 
	          4'd11:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 11
	                slv_reg11[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end 
	          4'd12:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 12
	                slv_reg12[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end 
	          4'd13:
	            for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )
	              if ( S_AXI_WSTRB[byte_index] == 1 ) begin
	                // Respective byte enables are asserted as per write strobes 
	                // Slave register 13
	                slv_reg13[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];
	              end 
	          default : begin
	                      slv_reg0 <= slv_reg0;
	                      slv_reg1 <= slv_reg1;
	                      slv_reg2 <= slv_reg2;
	                      slv_reg3 <= slv_reg3;
	                      slv_reg4 <= slv_reg4;
	                      slv_reg5 <= slv_reg5;
	                      slv_reg6 <= slv_reg6;
	                      slv_reg7 <= slv_reg7;
	                      slv_reg8 <= slv_reg8;
	                      slv_reg9 <= slv_reg9;						  
	                      slv_reg10 <= slv_reg10;
	                      slv_reg11 <= slv_reg11;
	                      slv_reg12 <= slv_reg12;
	                      slv_reg13 <= slv_reg13;						  
	                    end
	        endcase
	      end
	  end
	end    

	// Implement write response logic generation
	// The write response and response valid signals are asserted by the slave 
	// when axi_wready, S_AXI_WVALID, axi_wready and S_AXI_WVALID are asserted.  
	// This marks the acceptance of address and indicates the status of 
	// write transaction.

	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      axi_bvalid  <= 0;
	      axi_bresp   <= 2'b0;
	    end 
	  else
	    begin    
	      if (axi_awready && S_AXI_AWVALID && ~axi_bvalid && axi_wready && S_AXI_WVALID)
	        begin
	          // indicates a valid write response is available
	          axi_bvalid <= 1'b1;
	          axi_bresp  <= 2'b0; // 'OKAY' response 
	        end                   // work error responses in future
	      else
	        begin
	          if (S_AXI_BREADY && axi_bvalid) 
	            //check if bready is asserted while bvalid is high) 
	            //(there is a possibility that bready is always asserted high)   
	            begin
	              axi_bvalid <= 1'b0; 
	            end  
	        end
	    end
	end   

	// Implement axi_arready generation
	// axi_arready is asserted for one S_AXI_ACLK clock cycle when
	// S_AXI_ARVALID is asserted. axi_awready is 
	// de-asserted when reset (active low) is asserted. 
	// The read address is also latched when S_AXI_ARVALID is 
	// asserted. axi_araddr is reset to zero on reset assertion.

	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      axi_arready <= 1'b0;
	      axi_araddr  <= 32'b0;
	    end 
	  else
	    begin    
	      if (~axi_arready && S_AXI_ARVALID)
	        begin
	          // indicates that the slave has acceped the valid read address
	          axi_arready <= 1'b1;
	          // Read address latching
	          axi_araddr  <= S_AXI_ARADDR;
	        end
	      else
	        begin
	          axi_arready <= 1'b0;
	        end
	    end 
	end       

	// Implement axi_arvalid generation
	// axi_rvalid is asserted for one S_AXI_ACLK clock cycle when both 
	// S_AXI_ARVALID and axi_arready are asserted. The slave registers 
	// data are available on the axi_rdata bus at this instance. The 
	// assertion of axi_rvalid marks the validity of read data on the 
	// bus and axi_rresp indicates the status of read transaction.axi_rvalid 
	// is deasserted on reset (active low). axi_rresp and axi_rdata are 
	// cleared to zero on reset (active low).  
	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      axi_rvalid <= 0;
	      axi_rresp  <= 0;
	    end 
	  else
	    begin    
	      if (axi_arready && S_AXI_ARVALID && ~axi_rvalid)
	        begin
	          // Valid read data is available at the read data bus
	          axi_rvalid <= 1'b1;
	          axi_rresp  <= 2'b0; // 'OKAY' response
	        end   
	      else if (axi_rvalid && S_AXI_RREADY)
	        begin
	          // Read data is accepted by the master
	          axi_rvalid <= 1'b0;
	        end                
	    end
	end  
	
	   // ��������
		wire  [7:0]  bm_year   ;    // ��ǰ����ֵ,BCD��
        wire  [9:0]  bm_yearday;    // BCD�� 
 		wire  [5:0]  bm_hour   ;    // ��ǰʱ��ֵ��BCD��
        wire  [6:0]  bm_minute ;    // BCD�� 
        wire  [6:0]  bm_second ;    // BCD��
		wire  [16:0] bm_daysec ;    // ���룬������ 	   

		wire  [7:0]  curr_year   ;   // ��ǰ����ֵ,BCD��
        wire  [4:0]  curr_month  ;   // BCD�� 
        wire  [5:0]  curr_day    ;   // BCD�� 
        wire  [6:0]  curr_week   ;   // ������
        wire  [9:0]  curr_yearday;   // BCD�� 
 		wire  [5:0]  curr_hour   ;   // ��ǰʱ��ֵ��BCD��
        wire  [6:0]  curr_minute ;   // BCD�� 
        wire  [6:0]  curr_second ;   // BCD��
		wire  [16:0] curr_daysec ;   // ���룬������ 
        wire  [23:0] curr_subsec ;   // ���룬������	
		
	    wire  [31:0] onoff_dout;     // ��������
        wire         onoff_latch;	 // �����ش�ʱ��	
	    wire  [7:0]  data_rdserial;  // ��������
		
	   //ʱ������	
 		reg   [5:0]  latch_hour   ;   // BCD��
        reg   [6:0]  latch_minute ;   // BCD�� 
        reg   [6:0]  latch_second ;   // BCD��
		reg   [16:0] latch_daysec ;   // ���룬������ 
        reg   [23:0] latch_subsec ;   // ���룬������		

	// Implement memory mapped register select and read logic generation
	// Slave register read enable is asserted when valid address is available
	// and the slave is ready to accept the read address.
	assign slv_reg_rden = axi_arready & S_AXI_ARVALID & ~axi_rvalid;
	always @(*)
	begin
	      // Address decoding for reading registers
	      case ( axi_araddr[ADDR_LSB+OPT_MEM_ADDR_BITS:ADDR_LSB] )  
		  //��ǰB������ʱ������
	        4'h0   : reg_data_out <= {14'd0, bm_year, bm_yearday};
	        4'h1   : reg_data_out <= {12'd0, bm_hour, bm_minute, bm_second};
	        4'h2   : reg_data_out <= {15'd0, bm_daysec};
		  //��ʱ�ӵ�ʵʱʱ������
	        4'h3   : reg_data_out <= {14'd0, curr_year, curr_yearday};
	        4'h4   : reg_data_out <= {14'd0, curr_month, curr_day, curr_week};
	        4'h5   : reg_data_out <= {12'd0, curr_hour, curr_minute, curr_second};
	        4'h6   : reg_data_out <= {15'd0, curr_daysec};
	        4'h7   : reg_data_out <= {8'd0,  curr_subsec};
		  //��������д�������������ü����϶���	
	        4'h8   : reg_data_out <= {onoff_done,15'd0,wrserial_done,15'd0};
	        4'h9   : reg_data_out <= onoff_dout;   //datas read from 74HC165 		
	        4'd10  : reg_data_out <= {24'd0,data_rdserial};  //fail signals
		  //ʱ������	
	        4'd11  : reg_data_out <= {12'd0, latch_hour, latch_minute, latch_second};			
	        4'd12  : reg_data_out <= {15'd0, latch_daysec};
	        4'd13  : reg_data_out <= {8'd0,  latch_subsec};						
	        default: reg_data_out <= 0;
	      endcase
	end

	// Output register or memory read data
	always @( posedge S_AXI_ACLK )
	begin
	  if ( S_AXI_ARESETN == 1'b0 )
	    begin
	      axi_rdata  <= 0;
	    end 
	  else
	    begin    
	      // When there is a valid read address (S_AXI_ARVALID) with 
	      // acceptance of read address by the slave (axi_arready), 
	      // output the read dada 
	      if (slv_reg_rden)
	        begin
	          axi_rdata <= reg_data_out;     // register read data
	        end   
	    end
	end    

	// Add user logic here
    soft_timer #
    	  (      	
          )			
	   soft_timer_inst(
       // system clock and reset signal   
    	.clkin(clk_10MHz     ),          // 10MHz
		.rst_n(CLK25MHz_RSTN ),          // ����25MHz�أ��첽��λ
		
	   // FPGA �ⲿ�˿�	  
		.pps_gps   (pps_gps   ),         // ����GPS����ͬ���źţ�����300ms
		.pps_in    (pps_in    ),         // ������ʱ��ֻҪ����ͬ��
		.irig_b_in (irig_b_in ),         // B�������źš������豸ͬ����Ҫ����ʾ��ʱ���̼���ʱ�ɹ�����
		.irig_b_out(irig_b_out),         // B�������һֱ��   
		.pps_50    (pps_50    ),         // pps���������50%ռ�ձȣ����ڼ���ڲ�ʱ���ȶ���
				
	   // FPGA�ڲ��˿�
		.pre_year   (slv_reg0[17:10]),  // Ԥ������ֵ,BCD��
        .pre_month  (slv_reg1[17:13]),  // BCD�� 
        .pre_day    (slv_reg1[12:7] ),  // BCD�� 
        .pre_week   (slv_reg1[6:0]  ),  // ������
        .pre_yearday(slv_reg0[9:0]  ),  // BCD�� 
 		.pre_hour   (slv_reg2[19:14]),  // Ԥ��ʱ��ֵ��BCD��
        .pre_minute (slv_reg2[13:7] ),  // BCD�� 
        .pre_second (slv_reg2[6:0]  ),  // BCD�� 
		.wr_date     (slv_reg3[0]   ),  // CPU���壬Ԥ����������ص�����   
        .wr_time     (slv_reg4[0]   ),  // CPU���壬Ԥ����ʱ����ص�����             
        .bm_encode_en(slv_reg5[0]   ),  // B��������ʹ���ź�
        .bm_decode_en(slv_reg6[0]   ),  // ����B��Уʱ��Уʱ�ɹ����Զ��ر�Ӳ��
        .pps_clr_en  (slv_reg7[0]   ),  // �������������ʹ���ź� 
		                                
	   // ��ǰBM�����ֵ
		.bm_year   (bm_year   ),    // ��ǰ����ֵ,BCD��
        .bm_yearday(bm_yearday),    // BCD�� 
 		.bm_hour   (bm_hour   ),    // ��ǰʱ��ֵ��BCD��
        .bm_minute (bm_minute ),    // BCD�� 
        .bm_second (bm_second ),    // BCD��
		.bm_daysec (bm_daysec ),    // ���룬������ 	   
	   
       //��ǰ��ʱ�ӵ�ֵ
		.curr_year   (curr_year    ),   // ��ǰ����ֵ,BCD��
        .curr_month  (curr_month   ),   // BCD�� 
        .curr_day    (curr_day     ),   // BCD�� 
        .curr_week   (curr_week    ),   // ������
        .curr_yearday(curr_yearday ),   // BCD�� 
 		.curr_hour   (curr_hour    ),   // ��ǰʱ��ֵ��BCD��
        .curr_minute (curr_minute  ),   // BCD�� 
        .curr_second (curr_second  ),   // BCD��
		.curr_daysec (curr_daysec  ),   // ���룬������ 
        .curr_subsec (curr_subsec  ),   // ���룬������	
		
       // CPU�ж������ź�
	    .pps_gps2cpu(pps_gps2cpu),     // 3��pps�źţ�����������ȷ��ʱ
	    .pps_in2cpu (pps_in2cpu ),
        .pps_bm2cpu (pps_bm2cpu ),
	    .bm_syn_end (bm_syn_end ),     // B�����ɹ����������ʱ�ӵ�ͬ��	
		.date_update(date_update)      // 00:00:00���ˣ�����CPU������������
	); 
	
    onoff_io onoff_inst(
          //����������       
		  //FPGA interface
           .clkin   (CLK25MHz       ),       //25MHz  main clock
           .rst_n   (CLK25MHz_RSTN  ),       // low actively
           .start   (slv_reg8[24]   ),       //start one write&read or reset last status
           .byte_num(slv_reg8[18:16]),       //1,2,3,4 refer to 8,16,24,32 of the io bits respectively
           .rw_modes(slv_reg8[31:30]),
           .din     (slv_reg13      ),       //datas writted to TPIC6B595
           .dout    (onoff_dout     ),       //datas read from 74HC165   
           .done    (onoff_done     ),       //feedback to CPU 
		   .latch_time(onoff_latch  ),
           //board interface      
           .cs   (onoff_cs  ),		   
           .sclk (onoff_sclk),         
           .sdo  (onoff_sdo ),
           .sdi  (onoff_sdi )            
         );     
		 
    config2ser16bits wrserial_inst(
         //����DAC����������?
         //FPGA interface
          .clkin    (CLK25MHz     ),           //25MHz  main clock
          .rst_n    (CLK25MHz_RSTN),
          .start    (slv_reg8[8]  ),             //start one congfiguration
          .ld1595_en(slv_reg8[0]  ),
          .ld595_en (slv_reg8[1]  ),
          .din0     (slv_reg9     ),        //ub + ua  
          .din1     (slv_reg10    ),        //ux + uc  
          .din2     (slv_reg11    ),        //ib + ia  
          .din3     (slv_reg12    ),        //ix + ic  
          .config_done(wrserial_done),      //feedback to CPU 
          //ADDA board interface
          .load(wrserial_load),           //LD_W            
          .sclk(wrserial_sclk),           //CLK_W 
          .sdo (wrserial_sdo )            //DATA_W
          );		 
	
   rd_from_serial8bit  rd_serial_inst(
          //8·�����ź�ʧЧ����
	      //FPGA interface
          .clkin      (CLK25MHz     ),         //25MHz  main clock
          .rst_n      (CLK25MHz_RSTN),
          .enable     (slv_reg8[9]  ),
          .dataout    (data_rdserial),         //
	      //ADDA board interface
          .load_n     (rdserial_load),         //LD_R
          .sclk       (rdserial_sclk),         //CLK_R
          .sdi        (rdserial_sdi )	         //DATA_R
          );	
	
     //////////////////////////////////////////////////////////////////
	   reg   [1:0]  latch_dly;
       wire         latch_posedge;
	   
 	  always @( posedge S_AXI_ACLK )
	     begin
	       if ( S_AXI_ARESETN == 1'b0 )
	          latch_dly <= 2'd0; 
	       else      
		      latch_dly <= {latch_dly[0],onoff_latch};		  
          end
       assign latch_posedge = ~latch_dly[1] && latch_dly[0];
	
	//
	  always @( posedge S_AXI_ACLK )
	  begin
	    if ( S_AXI_ARESETN == 1'b0 )
	      begin
             latch_hour   <= 6'd0;  
             latch_minute <= 7'd0;
             latch_second <= 7'd0;
             latch_daysec <= 17'd0;	      
             latch_subsec <= 24'd0;		  		  
	      end 
	    else if( latch_posedge )
	      begin 	
             latch_hour   <= curr_hour  ; 
             latch_minute <= curr_minute; 
             latch_second <= curr_second; 
             latch_daysec <= curr_daysec;	
             latch_subsec <= curr_subsec;	
          end
      end  
	// User logic ends
   
	endmodule

